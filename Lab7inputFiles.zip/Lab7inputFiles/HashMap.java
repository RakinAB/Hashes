/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


public class HashMap {
  private final static int TABLE_SIZE = 100;

  HashEntry[] table;

  HashMap() {
       //Implement
  }

  public String get(int key) {
        // Implement
  }

  public void put(int key, String value) {
       // Implement
  }

  public void linearProbe(int key, String value){
     // Implement
  }

  public void quadraticProbe(int key, String value){
     // Implement
  }

}
