import * from HashEntry

class HashMap:
    TABLE_SIZE = 100

    table = HashEntry()[]

    def __init__(self):
        #implement

    def get(self, key):
        #implement

    def put(self, key, value):
        #implement

    def linear_probe(self, key, value):
        #implement

    def quadratic_probe(self, key, value):
        #implement