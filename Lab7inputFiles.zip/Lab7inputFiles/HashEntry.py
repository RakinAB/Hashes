class HashEntry:
    
    def __init__(self, key, value):
        self.key = key
        self.value = value

        